-- This Source Code Form is subject to the terms of the bCDDL, v. 1.1.
-- If a copy of the bCDDL was not distributed with this
-- file, You can obtain one at http://beamng.com/bCDDL-1.1.txt

local M = {}

local function onInit()
  electrics.values.lm_gear = 0
end

local function onReset()
	onInit()
end

local function updateGFX(dt)
  local g2 = math.fmod(math.abs(electrics.values.gear), 2) > 0
  if g2 then
    electrics.values.lm_gear = 1
  else
    electrics.values.lm_gear = 0
  end
end

-- public interface
M.onInit      = onInit
M.onReset     = onReset
M.updateGFX = updateGFX

return M