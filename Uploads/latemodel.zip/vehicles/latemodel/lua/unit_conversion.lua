-- This Source Code Form is subject to the terms of the bCDDL, v. 1.1.
-- If a copy of the bCDDL was not distributed with this
-- file, You can obtain one at http://beamng.com/bCDDL-1.1.txt

local M = {}

local cycleTest = false
local cycleDir = 1
local cycleVal = 0

local function onInit()
  electrics.values.oiltempF = 0
  electrics.values.watertempF = 0
end

local function onReset()
	onInit()
end

local function updateGFX(dt)
  if cycleTest then
    --cycle the gauges (TEST)
    cycleVal = cycleVal + ((dt * 0.25) * cycleDir)
    if cycleVal > 1 then cycleVal = 1 cycleDir = cycleDir * -1 end
    if cycleVal < 0 then cycleVal = 0 cycleDir = cycleDir * -1 end
    print(cycleVal)
    electrics.values.oiltempF = cycleVal * 250
    electrics.values.watertempF = cycleVal * 260
  else
    --convert the values to farenheit
    electrics.values.oiltempF = (1.8 * electrics.values.oiltemp) + 32
    electrics.values.watertempF = (1.8 * electrics.values.watertemp) + 32
  end
end

-- public interface
M.onInit      = onInit
M.onReset     = onReset
M.updateGFX = updateGFX

return M