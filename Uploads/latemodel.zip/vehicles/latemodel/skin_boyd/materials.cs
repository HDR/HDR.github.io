singleton Material("latemodel_body.skin.boyd")
{
   mapTo = "latemodel_body.skin.boyd";
   diffuseColor[0] = "1 1 1 1";
   diffuseColor[1] = "1 1 1 1";
   diffuseMap[0] = "vehicles/common/null.dds";
   diffuseMap[1] = "skin.dds";
   specularPower[0] = "5";
   pixelSpecular[1] = "1";
   useAnisotropic[1] = "1";
   dynamicCubemap = true;
   translucentBlendOp = "None";
};

singleton Material("latemodel_rim.skin.boyd")
{
   mapTo = "latemodel_rim.skin.boyd";
   diffuseColor[0] = "1 1 1 1";
   diffuseColor[1] = "1 1 1 0.9";
   diffuseMap[0] = "vehicles/common/null.dds";
   diffuseMap[1] = "skin.dds";
   specularPower[0] = "5";
   pixelSpecular[1] = "1";
   useAnisotropic[1] = "1";
   dynamicCubemap = true;
   translucentBlendOp = "None";
   doubleSided = "1";
};