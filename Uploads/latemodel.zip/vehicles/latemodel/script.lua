function test(str)
    jbeam:AppendLine("got text " .. str)
end

function COLTRI_SUFFIX(suffix, nd1, nd2, nd3, nd4, flip)
   flip = flip or false
   jbeam:Append('        ["')
   if flip then
    jbeam:Append(nd4 .. suffix .. '", "')
    jbeam:Append(nd3 .. suffix .. '", "')
    jbeam:Append(nd2 .. suffix .. '", "')
    jbeam:Append(nd1 .. suffix)
   else
    jbeam:Append(nd1 .. suffix .. '", "')
    jbeam:Append(nd2 .. suffix .. '", "')
    jbeam:Append(nd3 .. suffix .. '", "')
    jbeam:Append(nd4 .. suffix)
   end
   jbeam:Append('"],')
   jbeam:AppendLine()
end