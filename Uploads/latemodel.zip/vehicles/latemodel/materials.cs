singleton Material(LatemodelFBXASC045ChassisSG1)
{
   mapTo = "LatemodelFBXASC045ChassisSG1";
   diffuseColor[0] = "1 1 1 1";
   diffuseMap[0] = "details.dds";
   specular[0] = "0.769999981 0.769999981 0.769999981 1";
   specularPower[0] = "2";
   translucentBlendOp = "None";
};

singleton Material(LatemodelFBXASC045GlassSG)
{
   mapTo = "LatemodelFBXASC045GlassSG";
   diffuseColor[0] = "1 1 1 0.7";
   diffuseMap[0] = "glass.dds";
   specular[0] = "1.07000005 1.07000005 1.07000005 1";
   specularPower[0] = "5";
   translucent = "1";
   reflectivityMap[0] = "vehicles/common/glass_base.dds";
   dynamicCubemap = true;
   translucentBlendOp = "LerpAlpha";
   castShadows = "0";
};

singleton Material(latemodel_body)
{
   mapTo = "latemodel_body";
   diffuseColor[0] = "1 1 1 1";
   diffuseColor[1] = "1 1 1 1";
   diffuseColor[2] = "1 1 1 0.75";
   diffuseMap[0] = "vehicles/common/null.dds";
   diffuseMap[1] = "skin.dds";
   diffuseMap[2] = "skin_overlay.dds";
   instanceDiffuse[2] = true;
   specularPower[0] = "5";
   pixelSpecular[2] = "1";
   useAnisotropic[2] = "1";
   dynamicCubemap = true;
   translucentBlendOp = "None";
};

singleton Material(latemodel_rim)
{
   mapTo = "latemodel_rim";
   diffuseColor[0] = "1 1 1 1";
   diffuseMap[0] = "skin.dds";
   specularPower[0] = "5";
   translucentBlendOp = "None";
   doubleSided = "1";
};

singleton Material(LatemodelFBXASC045Wheel_FRSG1)
{
   mapTo = "LatemodelFBXASC045Wheel_FRSG1";
   diffuseColor[0] = "1 1 1 1";
   diffuseMap[0] = "tire.dds";
   specular[0] = "0.319999993 0.319999993 0.319999993 1";
   specularPower[0] = "128";
   translucentBlendOp = "None";
   doubleSided = "1";
};

singleton Material(LatemodelFBXASC045Spindle_LSG)
{
   mapTo = "LatemodelFBXASC045Spindle_LSG";
   diffuseColor[0] = "1 1 1 1";
   diffuseMap[0] = "details.dds";
   specular[0] = "0.769999981 0.769999981 0.769999981 1";
   specularPower[0] = "2";
   translucentBlendOp = "None";
};

singleton Material(LatemodelFBXASC045NoseScreenSG)
{
   mapTo = "LatemodelFBXASC045NoseScreenSG";
   diffuseMap[0] = "spring.dds";
   diffuseColor[0] = "1 1 1 1";
   specular[0] = "Black";
   specularPower[0] = "128";
   pixelSpecular[0] = "1";
   translucentBlendOp = "LerpAlpha";
   translucent = "1";
   doubleSided = "1";
};

singleton Material(LatemodelFBXASC045FrameSG)
{
   mapTo = "LatemodelFBXASC045FrameSG";
   diffuseColor[0] = "1 1 1 1";
   diffuseMap[0] = "spring.dds";
   specular[0] = "Black";
   specularPower[0] = "128";
   translucentBlendOp = "None";
   translucent = "0";
   alphaTest = "1";
   alphaRef = "128";
};

singleton Material(LatemodelFBXASC045ChassisSG2)
{
   mapTo = "LatemodelFBXASC045ChassisSG2";
   diffuseColor[0] = "Black";
   specular[0] = "Black";
   specularPower[0] = "128";
   translucentBlendOp = "None";
};

singleton Material(LATEMODELNEEDLE)
{
   mapTo = "latemodel_needle";
   diffuseColor[0] = "1 1 1 1";
   diffuseMap[0] = "needle.dds";
   translucentBlendOp = "None";
};

singleton Material(LATEMODELMIRROR)
{
   mapTo = "latemodel_mirror";
   diffuseColor[0] = "1 1 1 0";
   dynamicCubemap = true;
   translucentBlendOp = "None";
};

singleton Material(LatemodelPLASTIC)
{
   mapTo = "latemodel_plastic";
   diffuseColor[0] = "1 1 1 0.2";
   diffuseMap[0] = "glass.dds";
   diffuseMap[1] = "glass.dds";
   diffuseColor[1] = "1 1 1 0.25";
   specular[0] = "1.07000005 1.07000005 1.07000005 1";
   specularPower[0] = "5";
   translucent = "1";
   dynamicCubemap = true;
   translucentBlendOp = "LerpAlpha";
   castShadows = "1";
};

singleton Material(LatemodelWINDOWINT)
{
   mapTo = "latemodel_window_int";
   diffuseColor[0] = "1 1 1 0.13";
   diffuseMap[0] = "glass.dds";
   specular[0] = "1.07000005 1.07000005 1.07000005 1";
   specularPower[0] = "5";
   translucent = "1";
   translucentBlendOp = "LerpAlpha";
};
